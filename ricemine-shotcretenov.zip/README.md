ricemine-shotcrete

# new layout and practice for Ricemine - Shotcrete
